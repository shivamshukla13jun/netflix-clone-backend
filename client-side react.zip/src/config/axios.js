
/** base url to  make requests to the movie database */
const instance = {
    // baseURL: "http://localhost:7000/api/",
    baseURL: "https://netflixclone-k728.onrender.com/api/",
}
export default instance;