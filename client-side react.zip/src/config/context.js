import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react'
// const API_URL=`http://localhost:7000/api/movie/random`;
const API_URL=`https://netflixclone-k728.onrender.com/api/movie/random`;
const AppContext=React.createContext();

// we need to create a provider
const AppProvider=({children})=>{
    const [Actionmovie,setActionMovies]=useState([]);
    const [Comedynmovie,setComedyMovies]=useState([]);
    const [Horrormovie,setHorrorMovies]=useState([]);
    const [Warmovie,setWarMovies]=useState([]);
    const [Dramamovie,setDramaMovies]=useState([]);
    const [ScienceFictionmovie,setScienceFictionMovies]=useState([]);
    const [Action, setAction] = useState(["Action"])
    const [type, setType] = useState(["movie"])
    const [Comedy, setComedy] = useState(["Comedy"])
    const [Horror, setHorror] = useState(["Horror"])
    const [War, setWar] = useState(["War"])
    const [ScienceFiction, setScienceFiction] = useState(["Science Fiction"])
    const [Drama, setDrama] = useState(["Drama"])
    const [isLoading, setisLoading] = useState(true)

    useEffect(() => {
        const getActionMovies=(url)=>{
          setisLoading(true)
            axios
              .post(url, { genre: Action })
              .then((response) => {
                setisLoading(false)
                setActionMovies(response.data.result)
              })
              .catch((error) =>console.log(error))
        }
        const getComedMovies=(url)=>{
          setisLoading(true)
            axios
              .post(url, { genre: Comedy })
              .then((response) => {
                setisLoading(false)
                setComedyMovies(response.data.result)})
              .catch((error) =>console.log(error))
        }
        const getHorrorMovies=(url)=>{
          setisLoading(true)
            axios
              .post(url, { genre: Horror })
              .then((response) => {
                setisLoading(false)
                setHorrorMovies(response.data.result)})
              .catch((error) =>console.log(error))
        }
        const getWarMovies=(url)=>{
          setisLoading(true)
            axios
              .post(url, { genre: War })
              .then((response) =>{
                setisLoading(false)
                setWarMovies(response.data.result)
              })
              .catch((error) =>console.log(error))
        }
        const getDramaMovies=(url)=>{
          setisLoading(true)
            axios
              .post(url, { genre: Drama })
              .then((response) => {
                setisLoading(false)
                setDramaMovies(response.data.result)
              })
              .catch((error) =>console.log(error))
        }
        const getScienceFictionMovies=(url)=>{
            setisLoading(true)
            axios
              .post(url, { genre: ScienceFiction })
              .then((response) => {
                setisLoading(false)
                setScienceFictionMovies(response.data.result)
              })
              .catch((error) =>console.log(error))
        }
        getActionMovies(API_URL)
        getScienceFictionMovies(API_URL)
        getComedMovies(API_URL)
        getDramaMovies(API_URL)
        getWarMovies(API_URL)
        getHorrorMovies(API_URL)
      }, []);
const state={
  isLoading, Actionmovie,ScienceFictionmovie,Comedynmovie,Dramamovie,Warmovie,Horrormovie
}
    return   <AppContext.Provider value={state}>{children}</AppContext.Provider>;
};
const useGlobalContext=()=>{
    return useContext(AppContext);
}
export {AppContext,AppProvider,useGlobalContext}