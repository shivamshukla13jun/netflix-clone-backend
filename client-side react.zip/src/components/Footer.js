import React from 'react'

const Footer = () => {
  return (
   <>
   <div
     className="gen-footer-top"
     style={{ boxSizing: "border-box", padding: "60px 0px 0px" }}
   >
     <div
       className="container"
       style={{
         boxSizing: "border-box",
         width: "100%",
         paddingRight: "15px",
         paddingLeft: "15px",
         marginRight: "auto",
         marginLeft: "auto",
         maxWidth: "95%",
       }}
     >
       <div
         className="row"
         style={{
           boxSizing: "border-box",
           display: "flex",
           flexWrap: "wrap",
           marginRight: "-15px",
           marginLeft: "-15px",
         }}
       >
         <div
           className="col-xl-3 col-md-6"
           style={{
             boxSizing: "border-box",
             position: "relative",
             width: "100%",
             paddingRight: "15px",
             paddingLeft: "15px",
             flex: "0 0 25%",
             maxWidth: "25%",
           }}
         >
           <div
             className="widget"
             style={{
               boxSizing: "border-box",
               borderRadius: "0px",
               display: "inline-block",
               width: "100%",
               cssFloat: "left",
               position: "relative",
               background: "transparent",
               padding: "0px",
               border: "none",
               boxShadow: "none",
               marginBottom: "45px",
             }}
           >
             <div
               className="row"
               style={{
                 boxSizing: "border-box",
                 display: "flex",
                 flexWrap: "wrap",
                 marginRight: "-15px",
                 marginLeft: "-15px",
               }}
             >
               <div
                 className="col-sm-12"
                 style={{
                   boxSizing: "border-box",
                   position: "relative",
                   width: "100%",
                   paddingRight: "15px",
                   paddingLeft: "15px",
                   flex: "0 0 100%",
                   maxWidth: "100%",
                 }}
               >
                 <img
                   className="gen-footer-logo"
                   alt="gen-footer-logo"
                   src="http://template.gentechtreedesign.com/html/streamlab/red-html/images/logo-1.png"
                   style={{
                     boxSizing: "border-box",
                     borderStyle: "none",
                     verticalAlign: "middle",
                     maxWidth: "100%",
                     height: "60px",
                     marginBottom: "15px",
                   }}
                 />
                 <p
                   style={{
                     boxSizing: "border-box",
                     marginTop: "0px",
                     marginBottom: "30px",
                   }}
                 >
                   Lorem Ipsum is simply dummy text of the printing and
                   typesetting industry.
                 </p>
                 <ul
                   className="social-link"
                   style={{
                     boxSizing: "border-box",
                     padding: "0px",
                     margin: "0px",
                     paddingLeft: "0px",
                     marginTop: "0px",
                     marginBottom: "0px",
                   }}
                 >
                   <li
                     style={{
                       boxSizing: "border-box",
                       margin: "0px 0px 15px",
                       listStyle: "none",
                       cssFloat: "left",
                       marginRight: "30px",
                     }}
                   >
                     <a
                       className="facebook"
                       href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                       style={{
                         boxSizing: "border-box",
                         textDecoration: "none",
                         backgroundColor: "transparent",
                         transition: "all 0.5s ease-in-out 0s",
                         overflowWrap: "break-word",
                         position: "relative",
                         borderRadius: "0px",
                         fontSize: "18px",
                         lineHeight: "normal",
                         textAlign: "center",
                         display: "inline-block",
                         padding: "0px",
                         color: "#ffffff",
                         outline: "none",
                         marginRight: "0px",
                       }}
                     >
                       <i
                         className="fab fa-facebook-f"
                         style={{ boxSizing: "border-box" }}
                       />
                     </a>
                   </li>
                   <li
                     style={{
                       boxSizing: "border-box",
                       margin: "0px 0px 15px",
                       listStyle: "none",
                       cssFloat: "left",
                       marginRight: "30px",
                     }}
                   >
                     <a
                       className="facebook"
                       href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                       style={{
                         boxSizing: "border-box",
                         textDecoration: "none",
                         backgroundColor: "transparent",
                         transition: "all 0.5s ease-in-out 0s",
                         overflowWrap: "break-word",
                         position: "relative",
                         borderRadius: "0px",
                         fontSize: "18px",
                         lineHeight: "normal",
                         textAlign: "center",
                         display: "inline-block",
                         padding: "0px",
                         color: "#ffffff",
                         outline: "none",
                         marginRight: "0px",
                       }}
                     >
                       <i
                         className="fab fa-instagram"
                         style={{ boxSizing: "border-box" }}
                       />
                     </a>
                   </li>
                   <li
                     style={{
                       boxSizing: "border-box",
                       margin: "0px 0px 15px",
                       listStyle: "none",
                       cssFloat: "left",
                       marginRight: "30px",
                     }}
                   >
                     <a
                       className="facebook"
                       href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                       style={{
                         boxSizing: "border-box",
                         textDecoration: "none",
                         backgroundColor: "transparent",
                         transition: "all 0.5s ease-in-out 0s",
                         overflowWrap: "break-word",
                         position: "relative",
                         borderRadius: "0px",
                         fontSize: "18px",
                         lineHeight: "normal",
                         textAlign: "center",
                         display: "inline-block",
                         padding: "0px",
                         color: "#ffffff",
                         outline: "none",
                         marginRight: "0px",
                       }}
                     >
                       <i
                         className="fab fa-skype"
                         style={{ boxSizing: "border-box" }}
                       />
                     </a>
                   </li>
                   <li
                     style={{
                       boxSizing: "border-box",
                       margin: "0px 0px 15px",
                       marginBottom: "0px",
                       listStyle: "none",
                       cssFloat: "left",
                       marginRight: "0px",
                     }}
                   >
                     <a
                       className="facebook"
                       href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                       style={{
                         boxSizing: "border-box",
                         textDecoration: "none",
                         backgroundColor: "transparent",
                         transition: "all 0.5s ease-in-out 0s",
                         overflowWrap: "break-word",
                         position: "relative",
                         borderRadius: "0px",
                         fontSize: "18px",
                         lineHeight: "normal",
                         textAlign: "center",
                         display: "inline-block",
                         padding: "0px",
                         color: "#ffffff",
                         outline: "none",
                         marginRight: "0px",
                       }}
                     >
                       <i
                         className="fab fa-twitter"
                         style={{ boxSizing: "border-box" }}
                       />
                     </a>
                   </li>
                 </ul>
               </div>
             </div>
           </div>
         </div>
         <div
           className="col-xl-3 col-md-6"
           style={{
             boxSizing: "border-box",
             position: "relative",
             width: "100%",
             paddingRight: "15px",
             paddingLeft: "15px",
             flex: "0 0 25%",
             maxWidth: "25%",
           }}
         >
           <div
             className="widget"
             style={{
               boxSizing: "border-box",
               borderRadius: "0px",
               display: "inline-block",
               width: "100%",
               cssFloat: "left",
               position: "relative",
               background: "transparent",
               padding: "0px",
               border: "none",
               boxShadow: "none",
               marginBottom: "45px",
             }}
           >
             <h4
               className="footer-title"
               style={{
                 boxSizing: "border-box",
                 margin: "0px",
                 fontFamily: '"Jost", sans-serif',
                 textTransform: "capitalize",
                 fontWeight: 600,
                 marginTop: "0px",
                 letterSpacing: "0.02em",
                 overflowWrap: "break-word",
                 fontStyle: "normal",
                 padding: "0px",
                 marginBottom: "15px",
                 fontSize: "26px",
                 position: "relative",
                 lineHeight: "34px",
                 color: "#ffffff",
               }}
             >
               Explore
             </h4>
             <div
               className="menu-explore-container"
               style={{ boxSizing: "border-box" }}
             >
               <ul
                 className="menu"
                 style={{
                   boxSizing: "border-box",
                   padding: "0px",
                   margin: "0px",
                   paddingLeft: "0px",
                   marginTop: "0px",
                   marginBottom: "0px",
                 }}
               >
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     aria-current="page"
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Home
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/movies-pagination.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Movies
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/tv-shows-pagination.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Tv Shows
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/video-pagination.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Videos
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Actors
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Basketball
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Celebrity
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Cross
                   </a>
                 </li>
               </ul>
             </div>
           </div>
         </div>
         <div
           className="col-xl-3 col-md-6"
           style={{
             boxSizing: "border-box",
             position: "relative",
             width: "100%",
             paddingRight: "15px",
             paddingLeft: "15px",
             flex: "0 0 25%",
             maxWidth: "25%",
           }}
         >
           <div
             className="widget"
             style={{
               boxSizing: "border-box",
               borderRadius: "0px",
               display: "inline-block",
               width: "100%",
               cssFloat: "left",
               position: "relative",
               background: "transparent",
               padding: "0px",
               border: "none",
               boxShadow: "none",
               marginBottom: "45px",
             }}
           >
             <h4
               className="footer-title"
               style={{
                 boxSizing: "border-box",
                 margin: "0px",
                 fontFamily: '"Jost", sans-serif',
                 textTransform: "capitalize",
                 fontWeight: 600,
                 marginTop: "0px",
                 letterSpacing: "0.02em",
                 overflowWrap: "break-word",
                 fontStyle: "normal",
                 padding: "0px",
                 marginBottom: "15px",
                 fontSize: "26px",
                 position: "relative",
                 lineHeight: "34px",
                 color: "#ffffff",
               }}
             >
               Company
             </h4>
             <div
               className="menu-about-container"
               style={{ boxSizing: "border-box" }}
             >
               <ul
                 className="menu"
                 style={{
                   boxSizing: "border-box",
                   padding: "0px",
                   margin: "0px",
                   paddingLeft: "0px",
                   marginTop: "0px",
                   marginBottom: "0px",
                 }}
               >
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/contact-us.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Company
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/contact-us.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >{`Privacy
                                 Policy`}</a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/contact-us.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >{`Terms Of
                                 Use`}</a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/contact-us.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >{`Help
                                 Center`}</a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/contact-us.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     contact us
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/pricing-style-1.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Subscribe
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Our Team
                   </a>
                 </li>
                 <li
                   className="menu-item"
                   style={{
                     boxSizing: "border-box",
                     listStyle: "none",
                     margin: "0px 0px 15px",
                     marginBottom: "0px",
                     width: "calc(50% - 2px)",
                     display: "inline-block",
                   }}
                 >
                   <a
                     href="http://template.gentechtreedesign.com/html/streamlab/red-html/contact-us.html"
                     style={{
                       boxSizing: "border-box",
                       textDecoration: "none",
                       backgroundColor: "transparent",
                       transition: "all 0.5s ease-in-out 0s",
                       overflowWrap: "break-word",
                       border: "none",
                       padding: "5px 0px 5px 15px",
                       position: "relative",
                       display: "inline-block",
                       width: "100%",
                       color: "#ffffff",
                       outline: "none",
                     }}
                   >
                     Faq
                   </a>
                 </li>
               </ul>
             </div>
           </div>
         </div>
         <div
           className="col-xl-3 col-md-6"
           style={{
             boxSizing: "border-box",
             position: "relative",
             width: "100%",
             paddingRight: "15px",
             paddingLeft: "15px",
             flex: "0 0 25%",
             maxWidth: "25%",
           }}
         >
           <div
             className="widget"
             style={{
               boxSizing: "border-box",
               borderRadius: "0px",
               display: "inline-block",
               width: "100%",
               cssFloat: "left",
               position: "relative",
               background: "transparent",
               padding: "0px",
               border: "none",
               boxShadow: "none",
               marginBottom: "45px",
             }}
           >
             <h4
               className="footer-title"
               style={{
                 boxSizing: "border-box",
                 margin: "0px",
                 fontFamily: '"Jost", sans-serif',
                 textTransform: "capitalize",
                 fontWeight: 600,
                 marginTop: "0px",
                 letterSpacing: "0.02em",
                 overflowWrap: "break-word",
                 fontStyle: "normal",
                 padding: "0px",
                 marginBottom: "15px",
                 fontSize: "26px",
                 position: "relative",
                 lineHeight: "34px",
                 color: "#ffffff",
               }}
             >
               Downlaod App
             </h4>
             <div
               className="row"
               style={{
                 boxSizing: "border-box",
                 display: "flex",
                 flexWrap: "wrap",
                 marginRight: "-15px",
                 marginLeft: "-15px",
               }}
             >
               <div
                 className="col-sm-12"
                 style={{
                   boxSizing: "border-box",
                   position: "relative",
                   width: "100%",
                   paddingRight: "15px",
                   paddingLeft: "15px",
                   flex: "0 0 100%",
                   maxWidth: "100%",
                 }}
               >
                 <p
                   style={{
                     boxSizing: "border-box",
                     marginTop: "0px",
                     marginBottom: "30px",
                   }}
                 >
                   Lorem Ipsum is simply dummy text of the printing and
                   typesetting industry.
                 </p>
                 <a
                   href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                   style={{
                     boxSizing: "border-box",
                     textDecoration: "none",
                     backgroundColor: "transparent",
                     transition: "all 0.5s ease-in-out 0s",
                     color: "#e50916",
                     outline: "none",
                   }}
                 >
                   <img
                     className="gen-playstore-logo"
                     alt="playstore"
                     src="http://template.gentechtreedesign.com/html/streamlab/red-html/images/asset-35.png"
                     style={{
                       boxSizing: "border-box",
                       borderStyle: "none",
                       verticalAlign: "middle",
                       maxWidth: "100%",
                       display: "inline-block",
                       cssFloat: "left",
                       height: "38px",
                     }}
                   />
                 </a>
                 <a
                   href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                   style={{
                     boxSizing: "border-box",
                     textDecoration: "none",
                     backgroundColor: "transparent",
                     transition: "all 0.5s ease-in-out 0s",
                     color: "#e50916",
                     outline: "none",
                   }}
                 >
                   <img
                     className="gen-appstore-logo"
                     alt="appstore"
                     src="http://template.gentechtreedesign.com/html/streamlab/red-html/images/asset-36.png"
                     style={{
                       boxSizing: "border-box",
                       borderStyle: "none",
                       verticalAlign: "middle",
                       maxWidth: "100%",
                       display: "inline-block",
                       cssFloat: "left",
                       marginLeft: "15px",
                       height: "38px",
                     }}
                   />
                 </a>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
   <style
     dangerouslySetInnerHTML={{
       __html: `
html {
box-sizing: border-box;
font-family: sans-serif;
line-height: 1.15;
text-size-adjust: 100%;
-webkit-tap-highlight-color: transparent;
}

body {
box-sizing: border-box;
margin: 0px;
text-align: left;
background: #161616;
background-color: ;
font-family: "Roboto", sans-serif;
font-size: 1rem;
font-style: normal;
font-weight: normal;
line-height: 2;
color: #cecfd1;
overflow-x: hidden;
}
`,
     }}
   />
     <div
        className="gen-copyright-footer"
        style={{
          boxSizing: "border-box",
          padding: "15px 0px",
          background: "#e50916",
        }}
      >
        <div
          className="container"
          style={{
            boxSizing: "border-box",
            width: "100%",
            paddingRight: "15px",
            paddingLeft: "15px",
            marginRight: "auto",
            marginLeft: "auto",
            maxWidth: "95%",
          }}
        >
          <div
            className="row"
            style={{
              boxSizing: "border-box",
              display: "flex",
              flexWrap: "wrap",
              marginRight: "-15px",
              marginLeft: "-15px",
            }}
          >
            <div
              className="col-md-12 align-self-center"
              style={{
                boxSizing: "border-box",
                position: "relative",
                width: "100%",
                paddingRight: "15px",
                paddingLeft: "15px",
                flex: "0 0 100%",
                maxWidth: "100%",
                alignSelf: "center",
              }}
            >
              <span
                className="gen-copyright"
                style={{
                  boxSizing: "border-box",
                  textAlign: "center",
                  display: "inline-block",
                  width: "100%",
                }}
              >
                <a
                  href="http://template.gentechtreedesign.com/html/streamlab/red-html/index.html#"
                  target="_blank"
                  style={{
                    boxSizing: "border-box",
                    textDecoration: "none",
                    backgroundColor: "transparent",
                    transition: "all 0.5s ease-in-out 0s",
                    color: "#ffffff",
                    outline: "none",
                  }}
                >{`Copyright 2021 stremlab All Rights
                          Reserved.`}</a>
              </span>
            </div>
          </div>
        </div>
      </div>
      <style
        dangerouslySetInnerHTML={{
          __html: `
html {
  box-sizing: border-box;
  font-family: sans-serif;
  line-height: 1.15;
  text-size-adjust: 100%;
  -webkit-tap-highlight-color: transparent;
}

body {
  box-sizing: border-box;
  margin: 0px;
  text-align: left;
  background: #161616;
  background-color: ;
  font-family: "Roboto", sans-serif;
  font-size: 1rem;
  font-style: normal;
  font-weight: normal;
  line-height: 2;
  color: #cecfd1;
  overflow-x: hidden;
}
`,
        }}
      />
 </>
  )
}

export default Footer