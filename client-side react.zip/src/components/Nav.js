import React from 'react'
import { Link } from 'react-router-dom'

const Nav = () => {
 const genre= [
    "Drama",
    "Comedy",
    "Horror",
    "Science Fiction",
    "War",
    "Adventure",
    "Thriller","Thriller","TV Movie","TV Movie","TV Movie",
    "Fantasy","Fantasy","Fantasy","Fantasy"
    
]
  return (
    <header id="gen-header" className="gen-header-style-1 gen-has-sticky">
    <div className="gen-bottom-header">
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <nav className="navbar navbar-expand-lg navbar-light">
              <a className="navbar-brand" href="#">
                <img className="img-fluid logo" src="images/logo-1.png" alt="streamlab-image" />
              </a>
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <div id="gen-menu-contain" className="gen-menu-contain">
                  <ul id="gen-main-menu" className="navbar-nav ml-auto">
                    <li className="menu-item active">
                      <Link to="/" aria-current="page">Home</Link>
                    </li>
                    <li className="menu-item">
                      <a href="#">Movies</a>
                      <i className="fa fa-chevron-down gen-submenu-icon" />
                      <ul className="sub-menu">
                        <li className="menu-item menu-item-has-children">
                        {
                          genre.map((genre,idx)=>{
                              return <span key={idx}><Link className='item-link' 
                              to={"/genre/"+genre}>{genre }</Link></span>
                          })
                        }
                          <a href="#">Movies List</a>
                        </li>
                       
                      </ul>
                    </li>
                   
                  </ul>
                </div>
              </div>
             
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i className="fas fa-bars" />
              </button>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>
  )
}

export default Nav