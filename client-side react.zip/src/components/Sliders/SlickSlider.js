import React from 'react'

const SlickSlider = () => {
  return (
    <div>
           {/* <!-- Slick Slider start --> */}
   <section class="gen-section-padding-2 pt-0 pb-0">
      <div class="container">
         <div class="home-singal-silder">
            <div class="gen-nav-movies gen-banner-movies">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="slider slider-for">
                        {/* <!-- Slider Items --> */}
                        <div class="slider-item" style={{background:" url('/images/background/asset-4.jpeg')"}}>
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>thieve the bank</h3>
                                             <p>Streamlab is a long established fact that a reader will be distracted by
                                                the readable content of a page when Streamlab at its layout Streamlab.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="slider-item" style={{background:" url('/images/background/asset-23.jpeg')"}}>
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>Love your life</h3>
                                             <p>Streamlab is a long established fact that a reader will be distracted by
                                                the readable content of a page when Streamlab at its layout Streamlab.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="slider-item" style={{background:" url('/images/background/asset-24.jpeg')"}}>
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>The Last Witness</h3>
                                             <p>Streamlab is a long established fact that a reader will be distracted by
                                                the readable content of a page when Streamlab at its layout Streamlab.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="slider-item" style={{background:" url('/images/background/asset-25.jpeg')"}}>
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>Fight For Life</h3>
                                             <p>Streamlab is a long established fact that a reader will be distracted by
                                                the readable content of a page when Streamlab at its layout Streamlab.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        {/* <!-- Slider Items --> */}
                     </div>
                     <div class="slider slider-nav">
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="/images/background/asset-4.jpeg" alt="steamlab-image"/>
                           </div>
                           <div class="movie-info">
                              <h3>thieve the bank</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>30mins</li>
                                    <li>
                                       <a href="action.html">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="/images/background/asset-23.jpeg" alt="streamlab-image"/>
                           </div>
                           <div class="movie-info">
                              <h3>Love your life</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>1hr 46mins</li>
                                    <li>
                                       <a href="action.html">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="/images/background/asset-24.jpeg" alt="streamlab-image"/>
                           </div>
                           <div class="movie-info">
                              <h3>The Last Witness</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>1hr 37 mins</li>
                                    <li>
                                       <a href="action.html">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="/images/background/asset-25.jpeg" alt="streamlab-image"/>
                           </div>
                           <div class="movie-info">
                              <h3>Fight For Life</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>2hr 25 mins</li>
                                    <li>
                                       <a href="action.html">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   {/* <!-- Slick Slider End --> */}
    </div>
  )
}

export default SlickSlider