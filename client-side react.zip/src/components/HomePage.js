import React, { useState } from 'react'
import { useGlobalContext } from '../config/context'
import Banner1 from './Baeners/Bannerone';
import Caroesel from './Carosels/Caroesel';
import Slide from './Carosels/MultiCarousel';
const HomePage = () => {
  const { isLoading,Actionmovie,ScienceFictionmovie,Comedynmovie,Dramamovie,Warmovie,Horrormovie } = useGlobalContext();
  return (
    <div className='container' style={{marginTop:"100px"}}>
    <Caroesel Loading={isLoading} movies={Actionmovie} Headingtitle={"Action"}/>
    <Caroesel Loading={isLoading} movies={Comedynmovie} Headingtitle={"Comedy"}/>
    <Caroesel Loading={isLoading} movies={ScienceFictionmovie} Headingtitle={"Science Fiction"}/>
    <Caroesel Loading={isLoading}  movies={Dramamovie} Headingtitle={"Drama"}/>
    <Caroesel Loading={isLoading}  movies={Warmovie} Headingtitle={"War"}/>
    <Caroesel Loading={isLoading} movies={Horrormovie} Headingtitle={"Horror"}/>
    </div>
  )
}

export default HomePage