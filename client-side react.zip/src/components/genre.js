import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import instance from "../config/axios";
const GenreCategory = () => {
  const [movies, setMovies] = useState([]);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [totalPages, setTotalPages] = useState();
  const [totalPagesArray, setTotalPagesArray] = useState([]);
  const { genre } = useParams();
  const [trailerUrl, setTrailerUrl] = useState("");
  useEffect(() => {
    axios
      .post(instance.baseURL + "movie/random", { genre: [genre], limit, page })
      .then((response) => {
        setMovies(response.data.result);
        console.log(response.data.totalPage);
        setTotalPages(response.data.totalPage);
      })
      .catch((error) => console.log(error));
    //  console.log(request)
  }, []);
  let Arr=[]
  function toDigitsArr() {
    for (let i = 0; i < totalPages; i++) {
     Arr.push(i+1);
    }
  }
 toDigitsArr()
 console.log()
  return (
    <>
      <section class="gen-section-padding-3">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="row">
                {movies.map((movie) => {
                  return (
                    <div class="col-xl-3 col-lg-4 col-md-6">
                      <div class="gen-carousel-movies-style-3 movie-grid style-3">
                        <div class="gen-movie-contain">
                          <div class="gen-movie-img">
                            <img src={movie.imgSm} alt={movie.imgSm} />
                            <div class="gen-movie-add">
                              <div class="wpulike wpulike-heart">
                                <div class="wp_ulike_general_class">
                                  <a href="#" class="sl-button text-white">
                                    <i class="far fa-heart"></i>
                                  </a>
                                </div>
                              </div>
                              <ul class="menu bottomRight">
                                <li class="share top">
                                  <i class="fa fa-share-alt"></i>
                                  <ul class="submenu">
                                    <li>
                                      <a href="#" class="facebook">
                                        <i class="fab fa-facebook-f"></i>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="#" class="facebook">
                                        <i class="fab fa-instagram"></i>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="#" class="facebook">
                                        <i class="fab fa-twitter"></i>
                                      </a>
                                    </li>
                                  </ul>
                                </li>
                              </ul>
                              <div class="video-actions--link_add-to-playlist dropdown">
                                <a
                                  class="dropdown-toggle"
                                  href="#"
                                  data-toggle="dropdown"
                                >
                                  <i class="fa fa-plus"></i>
                                </a>
                                <div class="dropdown-menu mCustomScrollbar">
                                  <a class="login-link" href="#">
                                    Sign in to add this video to a playlist.
                                  </a>
                                </div>
                              </div>
                            </div>
                            <div class="gen-movie-action">
                            <Link to={"/singlemovie/"+movie._id}  class="gen-button">
            <i class="fa fa-play"></i>
          </Link>
                            </div>
                          </div>
                          <div class="gen-info-contain">
                            <div class="gen-movie-info">
                              <h3>
                                <a href="index.html">{movie.title}</a>
                              </h3>
                            </div>
                            <div class="gen-movie-meta-holder">
                              <ul>
                                <li>2 weeks</li>
                                <li>
                                  {
                                    // console.log({genre:movie.genre})
                                    movie.genre.map((genre, idx) => {
                                      return (
                                        <span key={idx}>
                                          <a
                                            className="item-link"
                                            href={"/genre/" + genre}
                                          >
                                            {(idx ? "," : "") + genre}
                                          </a>
                                        </span>
                                      );
                                    })
                                  }
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              {/* <div class="row">
                <div class="col-lg-12">
                  <div class="gen-pagination">
                    <nav aria-label="Page navigation">
                      <ul class="page-numbers">
                         {
                            Arr.map((pagenumbers)=>{
                               return <li>
                                <a class="page-numbers" href="#">
                                  {pagenumbers}
                                </a>
                              </li>
                            })
                         }
                        <li>
                          <span
                            aria-current="page"
                            class="page-numbers current"
                          >
                            1
                          </span>
                        </li>
                        <li>
                          <a class="page-numbers" href="#">
                            2
                          </a>
                        </li>
                        <li>
                          <a class="page-numbers" href="#">
                            3
                          </a>
                        </li>
                        <li>
                          <a class="next page-numbers" href="#">
                            Next page
                          </a>
                        </li>
                      </ul>
                    </nav>
                  </div>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default GenreCategory;
