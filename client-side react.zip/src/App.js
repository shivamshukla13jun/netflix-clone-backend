import React from 'react';
import './App.css';
import HomePage from './components/HomePage';
import SingleMovie from './components/SingleMovie';
import Layout from './components/Layout';
import { Switch,Route } from 'react-router-dom';
import GenreCategory from './components/genre';
function App() {
 
  return (
  <>
   <Layout>
    <Switch>
          <Route
            exact
            path="/"
            render={() => <HomePage />}
            
          />
          <Route
            exact
            path="/singlemovie/:id"
            render={() => <SingleMovie />}
          />
          <Route
            exact
            path="/genre/:genre"
            render={() => <GenreCategory />}
          />
         
        </Switch>
    </Layout>
  </>
  );
}

export default App;
