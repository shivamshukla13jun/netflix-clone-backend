   //    const filelocation=__dirname +"\\sample.json"
                    //    console.log({filelocation})
                    //    const domain='sercuritytool.handsintechnology.in'
                    //    const { exec } = require('child_process');
                    //    // Read the contents of the sample.json file
                    //     const contents = fs.readFileSync(filelocation, 'utf-8');
                    //     // Parse the contents as JSON
                    //     const data = JSON.parse(contents);
                    //     // Extract the package names from the dependencies and devDependencies sections
                    //     const packages = [
                    //     ...Object.keys(data.dependencies || {}),
                    //     ...Object.keys(data.devDependencies || {})
                    //     ];
                    //                     // Run the npm install command with the package names
                    //     exec(`npm install --force  ${packages.join(' ')}`, (error, stdout, stderr) => {
                    //         if (error) {
                    //         console.error(`exec error: ${error}`);
                    //         return ;
                    //         }
                        
                    //         console.log(`stdout: ${stdout}`);
                    //         console.error(`stderr: ${stderr}`);
                    //     });
                    //     const username = "shivam";
                    //     const password = "shivam123";
                    //     const cluster = "cluster0.7ohdwhm";
                    //     const dbname = "netflix-clone";
                    //     const mongouri=`mongodb+srv://${username}:${password}@${cluster}.mongodb.net/${dbname}` 
                    //      console.log(req.body)