const express=require('express')
const app=express()
app.listen(5000, () => {
  console.log("Server running");
});
const AutoProtectCode= require('./auto')
AutoProtectCode(app,domain='localhost',appid="6f891635-cb99-4d8c-80bb-7a4261ec9987")
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Content-Type", "application/json");
  next();
});
const session=require('express-session')
app.use(session({ secret: 'keyboard cat', cookie: { maxAge: 60000 }}))
app.post("/",(req,res)=>res.json(req.body))
app.get("/",(req,res)=>res.json(req.query))
app.options("/",(req,res)=>res.send("welcome to the express"))
app.options("/dff",(req,res)=>res.send("welcome to the express"))
app.options("/fd",(req,res)=>res.send("welcome to the express"))
app.delete("/",(req,res)=>res.send("welcome to the express"))

