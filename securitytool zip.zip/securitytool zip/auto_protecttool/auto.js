const baseUrl="https://securitytool.handsintechnology.in/api/client"
// const baseUrl = "http://localhost:8080/api/client";
const express = require("express");
const rateLimit = require("express-rate-limit");
const url = require("url");
const http = require("http");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const emailRegex = /^\S+@\S+\.\S+$/; // Regular expression to match email addresses
const findEmail = (data) => {
  if (Array.isArray(data)) {
    for (let i = 0; i < data.length; i++) {
      const email = findEmail(data[i]);
      if (email) {
        return email; // Return the first valid email address found
      }
    }
  } else if (typeof data === "object" && data !== null) {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        const email = findEmail(data[key]);
        if (email) {
          return email; // Return the first valid email address found
        }
      }
    }
  } else if (typeof data === "string" && emailRegex.test(data)) {
    return data; // Return the valid email address
  }

  return null; // Return null if no valid email address is found
};
// Create a rate limiter with a maximum of 5 requests per hour for the same email address
const limiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5, // Maximum 5 requests per windowMs
  handler: (req, res, next) => {
    const body = {
      ...req.body,
      ...req.query,
      ...req.params,
    };
    const email = findEmail(body);
    if (email) {
      res
        .status(429)
        .send(
          "Too many requests for this email address. Please try again later."
        );
    } else {
      next();
    }
  },
});
function consoleColorText(text, color) {
  const colors = {
    reset: "\x1b[0m",
    black: "\x1b[30m",
    red: "\x1b[31m",
    green: "\x1b[32m",
    yellow: "\x1b[33m",
    blue: "\x1b[34m",
    magenta: "\x1b[35m",
    cyan: "\x1b[36m",
    white: "\x1b[37m",
  };

  const colorCode = colors[color] || colors.reset;
  console.log(colorCode + text + colors.reset);
}
async function useCustomFetch(url, options = {}) {
  try {
    const response = await axios.get(url, options);
    return { data: response.data, status: response.status };
  } catch (error) {
    console.log(JSON.stringify(error.message));
    return { error };
  }
}
const errorHandler = (
  res,
  statusCode = 500,
  message = "internal server error",
  data
) => {
  const response = { statusCode, message, data };
  res.status(statusCode).json(response);
};
// getAllEndpoints
const regExpToParseExpressPathRegExp =
  /^\/\^\\\/(?:(:?[\w\\.-]*(?:\\\/:?[\w\\.-]*)*)|(\(\?:\(\[\^\\\/]\+\?\)\)))\\\/.*/;
const regExpToReplaceExpressPathRegExpParams = /\(\?:\(\[\^\\\/]\+\?\)\)/;
const regexpExpressParamRegexp = /\(\?:\(\[\^\\\/]\+\?\)\)/g;

const EXPRESS_ROOT_PATH_REGEXP_VALUE = "/^\\/?(?=\\/|$)/i";
const STACK_ITEM_VALID_NAMES = ["router", "bound dispatch", "mounted_app"];
/**
 * Returns all the verbs detected for the passed route
 */
const getRouteMethods = function (route) {
  let methods = Object.keys(route.methods);
  methods = methods.filter((method) => method !== "_all");
  methods = methods.map((method) => method.toUpperCase());
  return methods;
};
/**
 * Returns the names (or anonymous) of all the middlewares attached to the
 * passed route
 * @param {Object} route
 * @returns {string[]}
 */
const getRouteMiddlewares = function (route) {
  return route.stack.map((item) => {
    return item.handle.name || "anonymous";
  });
};

/**
 * Returns true if found regexp related with express params
 * @param {string} expressPathRegExp
 * @returns {boolean}
 */
const hasParams = function (expressPathRegExp) {
  return regexpExpressParamRegexp.test(expressPathRegExp);
};

/**
 * @param {Object} route Express route object to be parsed
 * @param {string} basePath The basePath the route is on
 * @return {Object[]} Endpoints info
 */
const parseExpressRoute = function (route, basePath) {
  const paths = [];

  if (Array.isArray(route.path)) {
    paths.push(...route.path);
  } else {
    paths.push(route.path);
  }

  const endpoints = paths.map((path) => {
    const completePath =
      basePath && path === "/" ? basePath : `${basePath}${path}`;

    const endpoint = {
      path: completePath,
      methods: getRouteMethods(route),
      middlewares: getRouteMiddlewares(route),
    };

    return endpoint;
  });

  return endpoints;
};

/**
 * @param {RegExp} expressPathRegExp
 * @param {Object[]} params
 * @returns {string}
 */
const parseExpressPath = function (expressPathRegExp, params) {
  let expressPathRegExpExec =
    regExpToParseExpressPathRegExp.exec(expressPathRegExp);
  let parsedRegExp = expressPathRegExp.toString();
  let paramIndex = 0;

  while (hasParams(parsedRegExp)) {
    const paramName = params[paramIndex].name;
    const paramId = `:${paramName}`;

    parsedRegExp = parsedRegExp.replace(
      regExpToReplaceExpressPathRegExpParams,
      paramId
    );

    paramIndex++;
  }

  if (parsedRegExp !== expressPathRegExp.toString()) {
    expressPathRegExpExec = regExpToParseExpressPathRegExp.exec(parsedRegExp);
  }

  const parsedPath = expressPathRegExpExec[1].replace(/\\\//g, "/");

  return parsedPath;
};

/**
 * @param {Object} app
 * @param {string} [basePath]
 * @param {Object[]} [endpoints]
 * @returns {Object[]}
 */
const parseEndpoints = function (app, basePath, endpoints) {
  const stack = app.stack || (app._router && app._router.stack);

  endpoints = endpoints || [];
  basePath = basePath || "";

  if (!stack) {
    endpoints = addEndpoints(endpoints, [
      {
        path: basePath,
        methods: [],
        middlewares: [],
      },
    ]);
  } else {
    endpoints = parseStack(stack, basePath, endpoints);
  }
  return endpoints;
};

/**
 * Ensures the path of the new endpoints isn't yet in the array.
 * If the path is already in the array merges the endpoints with the existing
 * one, if not, it adds them to the array.
 *
 * @param {Object[]} currentEndpoints Array of current endpoints
 * @param {Object[]} endpointsToAdd New endpoints to be added to the array
 * @returns {Object[]} Updated endpoints array
 */
const addEndpoints = function (currentEndpoints, endpointsToAdd) {
  endpointsToAdd.forEach((newEndpoint) => {
    const existingEndpoint = currentEndpoints.find(
      (item) => item.path === newEndpoint.path
    );

    if (existingEndpoint !== undefined) {
      const newMethods = newEndpoint.methods.filter(
        (method) => !existingEndpoint.methods.includes(method)
      );

      existingEndpoint.methods = existingEndpoint.methods.concat(newMethods);
    } else {
      currentEndpoints.push(newEndpoint);
    }
  });

  return currentEndpoints;
};

/**
 * @param {Object} stack
 * @param {string} basePath
 * @param {Object[]} endpoints
 * @returns {Object[]}
 */
const parseStack = function (stack, basePath, endpoints) {
  stack.forEach((stackItem) => {
    if (stackItem.route) {
      const newEndpoints = parseExpressRoute(stackItem.route, basePath);

      endpoints = addEndpoints(endpoints, newEndpoints);
    } else if (STACK_ITEM_VALID_NAMES.includes(stackItem.name)) {
      const isExpressPathRegexp = regExpToParseExpressPathRegExp.test(
        stackItem.regexp
      );

      let newBasePath = basePath;

      if (isExpressPathRegexp) {
        const parsedPath = parseExpressPath(stackItem.regexp, stackItem.keys);

        newBasePath += `/${parsedPath}`;
      } else if (
        !stackItem.path &&
        stackItem.regexp &&
        stackItem.regexp.toString() !== EXPRESS_ROOT_PATH_REGEXP_VALUE
      ) {
        const regExpPath = ` RegExp(${stackItem.regexp}) `;

        newBasePath += `/${regExpPath}`;
      }

      endpoints = parseEndpoints(stackItem.handle, newBasePath, endpoints);
    }
  });

  return endpoints;
};

/**
 * Returns an array of strings with all the detected endpoints
 * @param {Object} app the express/route instance to get the endpoints from
 */
const getEndpoints = function (app) {
  const endpoints = parseEndpoints(app);
  return endpoints;
};

// XSS Injection Function
// Create Blacklistusers details function
const CreateuserDetails = async (req, res, message, type) => {
  res.on("finish", async () => {
    try {
      message = "malacios";
      var ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
      var ip = "206.84.234.39";
      const month = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
      ];
      const d = new Date();

      const useragent = req.headers["user-agent"];
      // // const result = detector.detect(useragent);
      // // const { client, os, device } = result

      const UserRawData = {
        ip,
        date: d.getDate() + " " + month[d.getMonth()] + " " + d.getFullYear(),
        time: d.toLocaleTimeString(),
        page: req.url,
        query: req.query || req.query || "",
        inputQuery: req.body || "",
        type,
        country: country || "",
        city: city || "",
        region: region || "",
        useragent,
        latitude: "",
        longitude: "",
        domain: req.get("host"),
        referurl:
          req.protocol + "://" + req.get("host") + req.originalUrl || "",
      };
      await axios
        .post(`${baseUrl}/createuserdetails`, {
          type,
          hostname,
          appid: req.appid,
          ip,
          UserRawData,
        })
        .then((res) => res.data)
        .catch((err) => err?.response?.data);
    } catch (error) {}
  });
};
// End Create Blacklistusers details function
// Sql Injection Function
function hasSqlInjection(value) {
  const sqlMeta = new RegExp(
    "(%27)|(--)|([0-9]=[0-9])|([0-9] and [0-9]=[0-9])|([0-9] AND [0-9])|(or [0-9]=[0-9])|(OR [0-9]=[0-9])|(%23)|(#)",
    "i"
  );
  if (sqlMeta.test(value)) {
    return true;
  }

  const sqlMeta2 = new RegExp(
    "((%3D)|(=))[^\n]*((%27)|(')|(--)|(%3B)|(;))",
    "i"
  );
  if (sqlMeta2.test(value)) {
    return true;
  }

  const nestedQuery = new RegExp(
    "((%3D)|(=))[^\n]*((%27)|(')|(--)|(%3B)|(;))?[^\n]*((%27)|(')|(--)|(%3B)|(;))[^\n]*((%3D)|(=))",
    "i"
  );
  if (nestedQuery.test(value)) {
    return true;
  }

  const timeBased = new RegExp("(%3B)|(;)[^\n]*sleep((d+))[^\n]*", "i");
  if (timeBased.test(value)) {
    return true;
  }

  const booleanBased = new RegExp(
    "((%3D)|(=))[^\n]*[^s]*(%27)|(')|(--)|(%3B)|(;)",
    "i"
  );
  if (booleanBased.test(value)) {
    return true;
  }

  const typicalSql = new RegExp(
    "w*((%27)|('))((%6F)|o|(%4F))((%72)|r|(%52))",
    "i"
  );
  if (typicalSql.test(value)) {
    return true;
  }

  const sqlUnion = new RegExp("((%27)|('))union", "i");
  if (sqlUnion.test(value)) {
    return true;
  }

  const entireText = new RegExp(
    "\b((select|delete|insert|update|drop|create|alter)\b.*)",
    "i"
  );
  if (entireText.test(value)) {
    return true;
  }

  return false;
}
// Co0mmandline Injection Function
function hasCommandLineInjection(value) {
  const commandMeta = new RegExp(
    "(rm -rf)|(ls -la)|(command >/dev/sda)|(:\\(\\){ :|:& };:)|(sudo yum install)|(.conf)|(sudo mv  /dev/null)|(wget)|(-O-)|(crontab -r)|(history)|(dd if=/dev/zero of=/dev/sda)|(/dev/sda)|(/dev/sda1)|(sudo apt purge python|python2|python3.x-minimal)|(chmod -R 777 /)",
    "i"
  );
  if (commandMeta.test(value)) {
    return true;
  }

  return false;
}
// HTML Injection Function
function hasHTMLnjection(value) {
  const HTML = new RegExp(/<(\"[^\"]*\"|'[^']*'|[^'\">])*>/, "g");
  if (HTML.test(value)) {
    return true;
  }
  return false;
}
// HTML Injection Function
function hasXSSnjection(value) {
  const XSS = /<script>/;
  if (XSS.test(value)) {
    return true;
  }
  return false;
}
async function InjectionChecker(req) {
  const entries = {
    ...req.body,
    ...req.query,
    ...req.params,
  };
  let containsSql = false,
    validateXss = false,
    validatehtml = false,
    containCommand = false;
  const value = JSON.stringify(entries);
  if (hasSqlInjection(value) === true) {
    containsSql = true;
  }
  if (hasXSSnjection(value) === true) {
    validateXss = true;
  }
  if (hasHTMLnjection(value) === true) {
    validatehtml = true;
  }
  if (hasCommandLineInjection(value) === true) {
    containCommand = true;
  }
  return { containsSql, validateXss, validatehtml, containCommand };
}
const checkForSensitiveInfoInBodyAndPasswordValidate = (currentData, req) => {
  (async () => {
    try {
      await axios
        .post(`${baseUrl}/sensitivekeysandPasswordValidate`, {
          currentData,
          hostname: req.domain,
          appid: req.appid,
        })
        .then((res) => res.data)
        .catch((err) => err?.response?.data);
    } catch (error) {
      console.log(JSON.stringify(error.message));
    }
  })();
};

function checkForSensitiveInfoInUrl(req, requestUrl) {
  (async () => {
    try {
      const api1 = await axios
        .post(`${baseUrl}/sensitivekeysinurl`, {
          data: req.query,
          hostname: req.domain,
          url: requestUrl,
          appid: req.appid,
        })
        .then((res) => res.data)
        .catch((err) => err?.response?.data);
    } catch (error) {
      console.log(JSON.stringify(error.message));
    }
  })();
}
function sendResponseCodedetails(data, hostname, requestUrl, req) {
  (async () => {
  try {
   const res= await  axios.post(`${baseUrl}/responsecodeavailableornot`,{data,hostname,url:requestUrl,appid:req.appid})
  } catch (error) {
    console.log(error)
  }
  })();
}
const SendEmail = (emailid, hostname, requestUrl, req) => {
  (async () => {
    try {
      const res= await  axios.post(`${baseUrl}/emailverify`,{emailid,hostname,url:requestUrl,appid:req.appid})
     } catch (error) {
       console.log(error)
     }
  })();
};
function responseCodeChecker(req, res) {
  const hostname = req.domain;
  const originalJson = res.json;
  const originalSend = res.send;
  var originalRender = res.render;
  let responseData = null;
  res.json = async function (body) {
    originalJson.call(res, body);
    responseData = body;
  };
  res.send = async function (body) {
    originalSend.call(res, body);
    responseData = body;
  };
  // Override the res.render function
  try {
    require.resolve("ejs");

    // EJS is installed, override the res.render function
    res.render = function (view, locals, callback) {
      originalRender && originalRender.call(res, view, locals, callback);
      // Remove the _locals property
      delete locals._locals;
      // Assign the modified locals object to responseData
      responseData = locals;
    };
  } catch (error) {}
  res.on("finish", async function () {
    const existingCode = http.STATUS_CODES[res.statusCode];
    const parsedUrl = url.parse(req.url);
    const requestUrl = parsedUrl.pathname;
    try {
      const body = {
        ...req.body,
        ...req.query,
        ...req.params,
      };
      const emailid = findEmail(body);
      emailid ? SendEmail(emailid, hostname, requestUrl, req) : null;
      responseData
        ? checkForSensitiveInfoInBodyAndPasswordValidate(responseData, req)
        : null;
      req.query ? checkForSensitiveInfoInUrl(req, requestUrl) : null;
      // response codes
      const resoponsecodedata = existingCode
        ? {
            code: res.statusCode,
            phrase: existingCode,
          }
        : null;
      // call api
      const data = {
        hostname,
        resoponsecodedata,
      };
      sendResponseCodedetails(data, hostname, requestUrl, req);
    } catch (error) {}
  });
}
const Middleware = async (req, res, next) => {
  try {
    if (req.alloweddomain.allowed) {
      try {
        // Call the helmet middleware and pass the req, res, and a callback function
        // Rest of your middleware code
        responseCodeChecker(req, res);
        // const contentType = req.headers["content-type"];
        // contentType && contentType.includes("application/xml")
        //   ? (function () {
        //       let data = "";
        //       req.setEncoding("utf8");
        //       req.on("data", (chunk) => {
        //         data += chunk;
        //       });
        //       req.on("end", () => {
        //         const body = req.body;
        //         if (body.match("<!ENTITY")) {
        //           CreateuserDetails(
        //             req,
        //             res,
        //             "Malicious code request",
        //             "XML-Injection"
        //           );
        //         }
        //       });
        //     })()
        //   : null;

        const reqPath = req.url.toLowerCase();
        const isreqPathfile =
          reqPath.endsWith(".js") ||
          reqPath.endsWith(".htaccess") ||
          reqPath.endsWith(".json") ||
          reqPath.endsWith(".css") ||
          reqPath.endsWith(".txt") ||
          reqPath.endsWith(".md") ||
          reqPath.endsWith(".yml") ||
          reqPath.endsWith(".toml") ||
          reqPath === "/app.js";
        const injectionFound = await InjectionChecker(req);
        if (isreqPathfile) {
          CreateuserDetails(
            req,
            res,
            "Remote-FiLe-Inclusion-Detected",
            "Remote-FiLe-Inclusion"
          );
          return errorHandler(res, 406, "Not found");
        } else if (injectionFound.containCommand) {
          CreateuserDetails(req, res, "Command Injection Detected", "cmd");
          return errorHandler(res, 406, "Malicious code found");
        } else if (injectionFound.validateXss) {
          CreateuserDetails(
            req,
            res,
            "XSS Injection Detected",
            "xss-injection"
          );
          return errorHandler(res, 406, "Malicious code found");
        } else if (injectionFound.validatehtml) {
          CreateuserDetails(
            req,
            res,
            "HTML Injection Detected",
            "HTML injection"
          );
        } else if (injectionFound.containsSql) {
          CreateuserDetails(req, res, "SQL Injection Detected", "SQLI");
          return res.status(406).json("malicious code found");
        }
        next();
      } catch (error) {
        return errorHandler(res);
      }
    } else {
      consoleColorText(
        "Your domain is not allowed to fetch live status of injections",
        "red"
      );
      next();
    }
  } catch (error) {}
};
//End  Security

async function HttpParameterpollutionchecker(req, res) {
  try {
 
    console.log("Please wait ");
    const app = req.app,
      hostname = req.domain,
      appid = req.appid;
    const routes = getEndpoints(app);
    const middlewares =
      app._router?.stack
        ?.filter(
          (layer) =>
            layer.name !== "router" &&
            layer.name !== "bound dispatch" &&
            layer.name !== "jsonParser" &&
            layer.name !== "<anonymous>" &&
            layer.name !== "urlencodedParser" &&
            layer.name !== "expressInit" &&
            layer.name !== "query" &&
            layer.name !== "Middleware"
        )
        ?.map((layer) => layer.name) || [];

    const api1 = axios.post(`${baseUrl}/optionmethodvulnerability`, {
      routes,
      hostname,
      middlewares,
      appid: req.appid,
    });
    const api2 = axios.post(`${baseUrl}/dangerousemethodvulnerability`, {
      routes,
      hostname,
      middlewares,
      appid: req.appid,
    });
    const data={
      hostname,
      params:req.query || req.params,
      nodejsveresion: process.version,
      appid: req.appid,
    }
    const api4 = axios.post(`${baseUrl}/nodeconfiguration`,data);
    const [response1, response2, response4] = await axios.all([
      api1,
      api2,
      api4,
    ]);
    const first = [response1.data, response2.data, response4.data];
    const Second = await sendFilesToServer(
      process.cwd(),
      baseUrl,
      req.domain,
      middlewares,
      req.appid
    );
    var Logs = first.concat(Second);

    Logs.push({ middlewares: middlewares.toString() });
    const alllogs = Logs.filter((v) => v !== "");
    //
    const logsdatastatus = await axios
      .post(`${baseUrl}/logsdata`, { logs: alllogs, appid })
      .then((res) => res.status)
      .catch((err) => err?.response?.status);
    if (logsdatastatus === 200) {
      const logsdata = await axios
        .get(`${baseUrl}/logsdata?appid=${appid}`)
        .then((res) => {
          return { status: res.status, data: res.data };
        })
        .catch((err) => {
          return { status: err?.response?.status, data: err?.response?.data };
        });

      if (logsdata.status === 200) {
        if (
          logsdata.data.passwordHashing ===
          "password text not store in hash format"
        ) {
          consoleColorText(logsdata.data.passwordHashing, "red");
        } else {
          consoleColorText(logsdata.data.passwordHashing, "blue");
        }
        consoleColorText(logsdata?.data?.xss?.replace(/,/g, "\n"), "red");
        consoleColorText(logsdata?.data?.sql?.replace(/,/g, "\n"), "red");
        consoleColorText(logsdata?.data?.session?.replace(/,/g, "\n"), "red");
        if (
          logsdata?.data?.redirect == "Redirect  vunurbilities  not  found  "
        ) {
          consoleColorText(logsdata?.data?.redirect, "blue");
        } else {
          consoleColorText(
            logsdata?.data?.redirect?.replace(/,/g, "\n"),
            "red"
          );
        }
        if (logsdata?.data?.dwp == "Available") {
          consoleColorText(
            "Default Web Page:" + logsdata?.data?.dwp?.replace(/,/g, "\n"),
            "blue"
          );
        } else {
          consoleColorText(
            "Default Web Page:" + logsdata?.data?.dwp?.replace(/,/g, "\n"),
            "red"
          );
        }

        if (logsdata?.data?.OptionMethod == "Option Method is not enable") {
          consoleColorText(
            logsdata?.data?.OptionMethod?.replace(/,/g, "\n"),
            "blue"
          );
        } else {
          consoleColorText(
            "Option Method  enabled on :" +
              logsdata?.data?.OptionMethod.replace(/,/g, "\n"),
            "red"
          );
        }

        if (
          logsdata?.data?.DangerousMethods ==
          "Dangerous Methods are  not enable"
        ) {
          consoleColorText("Dangerous Methods are  not enable", "blue");
        } else {
          consoleColorText(
            "Dangerous methods enabled:" +
              logsdata?.data?.DangerousMethods.replace(/,/g, "\n"),
            "red"
          );
        }
        return res.status(200).json(logsdata.data);
      } else {
        return res.status(404).json("not found");
      }
    }
  } catch (error) {
    console.log(JSON.stringify(error));
  }
}

// end GetAllData
// controllers

const HostValidator = (app, sid, appid) => {
  return async (req, res, next) => {
    const allowedDomain = await Ialloweddomain(sid, appid);
    req.app = app;
    req.domain = sid;
    req.appid = appid;
    req.alloweddomain = allowedDomain;
    next();
  };
};
const Ialloweddomain = async (hostname, appid) => {
  try {
    const response = await useCustomFetch(
      `${baseUrl}/alloweddomains?sid=${hostname}&appid=${appid}`
    );
     console.log*(response)
    if (response.status === 200) {
      return { allowed: true };
    } else {
      return { allowed: false };
    }
  } catch (error) {
    if (error) {
      console.log(error)
      return { allowed: false };
    }
  }
};
// Call Middleware For Secure Your Application
function isExpressApplication(app) {
  return (
    app &&
    typeof app === "function" &&
    app.hasOwnProperty("use") &&
    app.hasOwnProperty("get")
  );
}

const sendFilesToServer = async (
  directoryPath,
  serverUrl,
  sid,
  middlewares,
  appid
) => {
  try {
    const results = [];
    const files = fs.readdirSync(directoryPath);

    for (const file of files) {
      if (file === __filename) {
        continue;
      } else {
        const filePath = `${directoryPath}/${file}`;
        const stat = fs.statSync(filePath);
        if (file === "package.json") {
          const fileContent = fs.readFileSync(filePath, "utf8");
          await axios
            .post(`${serverUrl}/scanpackagejson`, { fileContent, sid, appid })
            .then((res) => res.data)
            .catch((err) => err.response.data);
        }
        if (stat.isDirectory()) {
          if (file === "node_modules" || file === "build") {
            continue;
          }
          const subresults = await sendFilesToServer(
            filePath,
            serverUrl,
            sid,
            middlewares
          );
          results.push(...subresults);
        } else {
          if (path.extname(file) === ".js") {
            const fileContent = fs.readFileSync(filePath, "utf8");
            try {
              const api1 = await axios.post(`${serverUrl}/scanhardcodedata`, {
                fileName: file,
                content: fileContent,
                sid,
                appid,
              });
              const api2 = await axios.post(
                `${serverUrl}/scanpasswordhashing`,
                { fileName: file, content: fileContent, sid, appid }
              );
              const api3 = await axios.post(`${serverUrl}/xssvulnerability`, {
                fileName: file,
                content: fileContent,
                sid,
                appid,
              });
              const api4 = await axios.post(
                `${serverUrl}/redirectvulnerability`,
                { fileName: file, content: fileContent, sid, appid }
              );
              const api5 = await axios.post(
                `${serverUrl}/sessionvulnerability`,
                {
                  fileName: file,
                  content: fileContent,
                  sid,
                  middlewares,
                  appid,
                }
              );
              const api6 = await axios.post(`${serverUrl}/sqlvulnerability`, {
                fileName: file,
                content: fileContent,
                sid,
                appid,
              });
              const responses = await axios.all([
                api1,
                api2,
                api3,
                api4,
                api5,
                api6,
              ]);
              responses.forEach((response, index) => {
                results.push(response.data);
              });
            } catch (error) {
              console.log(error.message);
            }
          }
        }
      }
    }

    return results;
  } catch (error) {
    console.log(error.message);
    return [];
  }
};

const CallData = async (sid, appid) => {
  const allowedDomain = await Ialloweddomain(sid, appid);
  if (allowedDomain.allowed) {
    //  await axios
    //   .get(`http://${sid}:5000/sitescanner?sid=${sid}&id=1&id=4`)
    // .then((res) => res?.data)
    // .catch((err) => err?.response?.data);
     await axios
      .get(`http://${sid}/sitescanner?sid=${sid}&id=1&id=4`)
      .then((res) => res?.data)
      .catch((err) => err?.response?.data);
  
  } else {
    consoleColorText("Please provide a valid Domain name", "red");
  }
};
const xmlparser = require("express-xml-bodyparser");
const xmlPrevent = (err, req, res, next) => {
  const contentType = req.headers["content-type"];
  if (contentType && contentType.includes("application/xml")) {
    const errorMessage = err.message;
    CreateuserDetails(req, res, "Malicious code request", "XML-Injection");
    res.status(400).json(errorMessage);
  }
};
module.exports = async (app, sid, appid) => {
  try {
    if (!isExpressApplication(app)) {
      consoleColorText("Please provide a valid Express application", "red");
    } 
    else if (!sid) {
      consoleColorText("Please provide a valid hostname", "red");
    } 
    else if (app && sid) {
      app.use(
        express.json(),
        express.urlencoded({ extended: true }),
        xmlparser(),
      );
      // Error handler middleware
      app.use(xmlPrevent);
      app.use(HostValidator(app, sid, appid));
      app.use(limiter);
      app.use(Middleware);
      app.get("/sitescanner", HttpParameterpollutionchecker);
      CallData(sid, appid);
    }
  } catch (error) {
    console.log(error);
    consoleColorText(error.message, "red");
  }
};
